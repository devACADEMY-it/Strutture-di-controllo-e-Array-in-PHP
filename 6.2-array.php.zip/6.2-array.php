<!--

	Strutture di controllo e Array in PHP
	Array: la sintassi

	Disponibile su devACADEMY.it

-->

<?php

	$numeri[0]=10;
	echo $numeri[0];
	echo "<br>";

	$numeri[1]=20;
	echo $numeri[1];
	echo "<br>";

	$numeri[2]=$numeri[0]+$numeri[1];
	echo $numeri[2];
	echo "<br>";

	$numeri[]=35;
	echo $numeri[3];
	echo "<br>";

	$numeri[]="frase di esempio";
	echo $numeri[4];

	// inizializzare array velocemente
	$valori=array(2,3,4,5);
	echo "ultimo valore $valori[3]";
	echo "<br>";

	// da php 5.4
	$ultimo=[9,6,3,5];

?>