<!--

	Strutture di controllo e Array in PHP
	Cicli e Array

	Disponibile su devACADEMY.it

-->

<?php

	for ($i=2; $i<=10; $i++)
		for ($t=1; $t<=10; $t++)
			$tabelline[$i][$t]=$i*$t;

	var_dump($tabelline);

?>