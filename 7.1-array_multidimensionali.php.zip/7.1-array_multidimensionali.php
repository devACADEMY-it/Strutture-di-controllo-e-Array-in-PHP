<!--

	Strutture di controllo e Array in PHP
	Array multidimensionali

	Disponibile su devACADEMY.it

-->

<?php

	$matrice[0][1]=34;
	$matrice[2][3]=2;
	$matrice[3][1]=18;
	$matrice[0][4]=25;

	var_dump($matrice);

	echo "<br><br>";

	$misto['colori']=array('rosso', 'giallo', 'verde');
	$misto['fiori']=array('rosa', 'margherita');
	$misto['capitali']=array('francia' => 'parigi',
	'italia' => 'roma', 'spagna' => 'madrid');

	var_dump($misto);

	echo "<br><br>";

	echo $misto['colori'][1];
	echo "<br><br>";

	echo $misto['capitali']['spagna'];

?>