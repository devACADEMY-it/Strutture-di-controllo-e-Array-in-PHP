<!--

	Strutture di controllo e Array in PHP
	Esempio di manipolazione degli Array

	Disponibile su devACADEMY.it

-->

<?php

	$tutti=range(1,90);

	for ($i=0; $i<6; $i++)
	{
		shuffle($tutti);
		$estrazione[]=array_shift($tutti);
	}

	sort($estrazione);
	var_dump($estrazione);

?>