<!--

	Strutture di controllo e Array in PHP
	Percorrere gli Array con le funzioni

	Disponibile su devACADEMY.it

-->

<?php
	$spesa = array(
		'penne' => 12.5,
		'quaderni' => 4,
		'righello' => 2.5);

	while(list($key, $val)=each($spesa))
		echo "$key => $val <br>";
?>