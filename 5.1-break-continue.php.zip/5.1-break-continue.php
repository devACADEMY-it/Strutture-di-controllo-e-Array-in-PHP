<!--

	Strutture di controllo e Array in PHP
	Gestione dei cicli: break, continue

	Disponibile su devACADEMY.it

-->

<?php

	$i=0;
	for($i=0;$i<=20;$i++)
	{
		if ($i%2==0)
			continue;
		echo "$i <br>";
	}

	/*$somma=0;
	for ($i=0; $i<=50; $i++)
	{
		$somma+=$i;
		if ($somma>=30)
			break;
		echo "$somma <br>";
	}*/
	echo "FINE SCRIPT";

?>