<!--

	Strutture di controllo e Array in PHP
	Il ciclo while

	Disponibile su devACADEMY.it

-->

<?php

	$i=1;
	$tabellinadel=3;

	while($i<=0)
	{
		echo $tabellinadel*$i."<br>";
		$i++;
	}

?>