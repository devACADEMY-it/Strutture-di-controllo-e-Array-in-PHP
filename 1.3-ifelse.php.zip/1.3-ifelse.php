<!--

	Strutture di controllo e Array in PHP
	Il costrutto if-else

	Disponibile su devACADEMY.it

-->

<?php

	$numero=10;

	if ($numero>50)
		echo "$numero maggiore di 50";
	else
	        echo "$numero minore o uguale di 50";

?>