<!--

	Strutture di controllo e Array in PHP
	Esempio foreach

	Disponibile su devACADEMY.it

-->

<?php

	$carrello_spesa=
			array(
				array('codice_prodotto' => '001264567',
					  'aliquota_IVA' => 4,
					  'prezzo' => 15.00),
				array('codice_prodotto' => '005900567',
					  'aliquota_IVA' => 4,
					  'prezzo' => 21.00),
				array('codice_prodotto' => '009225565',
					  'aliquota_IVA' => 22,
					  'prezzo' => 34.00),
				array('codice_prodotto' => '006755554',
					  'aliquota_IVA' => 22,
					  'prezzo' => 23.00)
			);

	$totale=0;

	foreach ($carrello_spesa as $prodotto)
	{
		$prezzo=$prodotto['prezzo']*(1+$prodotto['aliquota_IVA']/100);
		$totale+=$prezzo;
		echo $prodotto['codice_prodotto']." ------ $prezzo <br>";
	}

	echo "Totale della fattura: $totale euro <br>";


?>