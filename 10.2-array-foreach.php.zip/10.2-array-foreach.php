<!--

	Strutture di controllo e Array in PHP
	Il costrutto foreach

	Disponibile su devACADEMY.it

-->

<?php

	$vettore = array(25,33,93,68,32);

	foreach($vettore as $v)
		echo "$v <br>";

	echo "<br><br>";

	foreach($vettore as $k => $v)
		echo "$k => $v <br>";

	echo "<br><br>";

	foreach($vettore as $k => &$v)
		$v+=2;

	var_dump($vettore);
?>