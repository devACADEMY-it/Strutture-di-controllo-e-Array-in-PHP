<!--

	Strutture di controllo e Array in PHP
	Il costrutto switch

	Disponibile su devACADEMY.it

-->

<?php

	$abbonamento="studenti";

	switch($abbonamento)
	{
		case "studenti":
			echo "sconto del 15%";
			break;
		case "over65":
			echo "sconto del 25%";
			break;

		default:
			echo "Prezzo intero";

	}

?>