<!--

	Strutture di controllo e Array in PHP
	Funzioni di ordinamento degli Array

	Disponibile su devACADEMY.it

-->

<?php

	$vettore=
	array( 12,56,78,3,123,55);

	var_dump($vettore);

	sort($vettore);
	var_dump($vettore);

	rsort($vettore);
	var_dump($vettore);

	shuffle($vettore);
	var_dump($vettore);

	$dueacaso=array_rand($vettore, 2);
	var_dump($dueacaso);

?>