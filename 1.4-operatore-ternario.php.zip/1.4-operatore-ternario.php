<!--

	Strutture di controllo e Array in PHP
	L'operatore ternario

	Disponibile su devACADEMY.it

-->

<?php

	$numero=1;

	echo ($numero>5)?"$numero maggiore di 5":"$numero minore o uguale di 5";

?>