<!--

	Strutture di controllo e Array in PHP
	Esempio riepilogativo sugli Array

	Disponibile su devACADEMY.it

-->

<?php

	  $studenti = array(
		'S12345' => array('nome' => 'Giacomo', 'cognome' => 'Rossi', 'eta'=> 22),
		'S67865' => array('nome' => 'Stefano', 'cognome' => 'Verdi', 'eta'=> 27),
		'S29384' => array('nome' => 'Rino', 'cognome' => 'Bianchi', 'eta'=> 19)
	  );

	  $totale=$studenti['S12345']['eta']+$studenti['S67865']['eta']+
		$studenti['S29384']['eta'];
	 echo $totale;
	 echo "<br><br>";

	 $eta_media=$totale/3;
	 echo "la media : $eta_media";
	 echo "<br><br>";

	 if ($studenti['S67865']['eta']>$studenti['S12345']['eta']
			&&
			$studenti['S67865']['eta']>$studenti['S29384']['eta'])
	 echo $studenti['S67865']['nome']." ".$studenti['S67865']['cognome']." nato prima
	 di tutti gli altri";
?>