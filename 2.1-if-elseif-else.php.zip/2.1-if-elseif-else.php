<!--

	Strutture di controllo e Array in PHP
	Il costrutto if-elseif-else

	Disponibile su devACADEMY.it

-->

<?php

	$eta=20;
	$tesserastudenti=FALSE;

	if ($eta<=8)
		echo "Accesso gratuito";
	elseif ($eta<=12)
		echo "Ingresso scontato del 20%";
	elseif ($tesserastudenti)
		echo "Ingresso scontato del 15%";
	else
		echo "Prezzo pieno";

?>