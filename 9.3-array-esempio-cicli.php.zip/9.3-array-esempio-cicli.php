<!--

	Strutture di controllo e Array in PHP
	Esempio array e costrutti

	Disponibile su devACADEMY.it

-->

<?php

	$materie=array("italiano", "matematica", "storia",
				   "geografia", "chimica", "fisica",
				   "inglese","filosofia", "latino",
				   "educazione fisica");

	for ($i=0; $i<count($materie); $i++)
	{
		$pagella[$materie[$i]]=rand(4,10);
		if ($pagella[$materie[$i]]<6)
			$insuff[$materie[$i]]=$pagella[$materie[$i]];
	}

	var_dump($pagella);

	if (empty($insuff))
		echo "Studente promosso!!";
	elseif (count($insuff)<4)
	{
		echo "Rimandato in ".count($insuff)." materie";
		var_dump($insuff);
	}
	else
	{
		echo "Studente bocciato!";
		var_dump($insuff);
	}

?>