<!--

	Strutture di controllo e Array in PHP
	Cicli for e condizioni

	Disponibile su devACADEMY.it

-->

<?php

	for ($i=0; $i<30; $i+=3)
	{
		echo $i;
		echo "<br>";
	}

	echo "<br>";

	for ($i=30; $i>=0; $i-=3)
	{
		echo $i;
		echo "<br>";
	}

?>