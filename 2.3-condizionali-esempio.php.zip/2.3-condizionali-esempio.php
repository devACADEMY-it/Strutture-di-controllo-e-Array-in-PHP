<!--

	Strutture di controllo e Array in PHP
	Esempio istruzioni condizionali

	Disponibile su devACADEMY.it

-->

<?php

	$votoPHPCandidato1=9;
	$votoIngleseCandidato1=6;

	$votoPHPCandidato2=8;
	$votoIngleseCandidato2=6;

	if ($votoPHPCandidato1>=9)
		$livello1=1;
	elseif ($votoPHPCandidato1>=8 && $votoIngleseCandidato1>=7)
		$livello1=2;
	else
		$livello1=3;

	if ($votoPHPCandidato2>=9)
		$livello2=1;
	elseif ($votoPHPCandidato2>=8 && $votoIngleseCandidato2>=7)
		$livello2=2;
	else
		$livello2=3;

	echo "Esito Candidato1<br>";

	switch($livello1)
	{
		case 1:
			echo "Assunto a tempo indeterminato<br>";
			break;
		case 2:
			echo "Assunto in prova<br>";
			break;
		default:
			echo "Non assunto<br>";
	}

	echo "Esito Candidato2<br>";

	switch($livello2)
	{
		case 1:
			echo "Assunto a tempo indeterminato<br>";
			break;
		case 2:
			echo "Assunto in prova<br>";
			break;
		default:
			echo "Non assunto<br>";
	}

	echo "Commento<br>";
	echo ($livello1==3 && $livello2==3)?"Siamo stati sfortunati":"Buona selezione";

?>