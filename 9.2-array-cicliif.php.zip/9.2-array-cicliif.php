<!--

	Strutture di controllo e Array in PHP
	Cicli Array e If

	Disponibile su devACADEMY.it

-->

<?php

	$vettore=
	array( 12,56,78,3,123,55,22,3);

	for ($i=0; $i<count($vettore); $i++)
		if ($vettore[$i]%2==0)
			$pari[]=$vettore[$i];
		else
			$dispari[]=$vettore[$i];

	var_dump($pari);
	var_dump($dispari);
?>