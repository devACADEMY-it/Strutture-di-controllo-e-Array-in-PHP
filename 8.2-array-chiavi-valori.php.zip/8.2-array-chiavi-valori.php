<!--

	Strutture di controllo e Array in PHP
	Funzioni su chiavi e valori

	Disponibile su devACADEMY.it

-->

<?php

	$capitali=
	array(
        'francia' => 'parigi',
		'italia' => 'roma',
        'spagna' => 'madrid',
		'portogallo' => 'lisbona');

	echo "Chiavi <br>";
	$chiavi=array_keys($capitali);
	var_dump($chiavi);
	echo "<br><br>";

	echo "Valori <br>";
	$valori=array_values($capitali);
	var_dump($valori);
	echo "<br><br>";

	if (array_key_exists('spagna', $capitali))
		echo "chiave spagna esiste <br>";
	else
		echo "chiave spagna NON esiste <br>";

	if (in_array('parigi', $capitali))
		echo "valore parigi esiste <br>";
	else
		echo "valore parigi NON esiste <br>";
	echo "<br><br>";

	echo array_search('roma', $capitali);
	echo "<br><br>";

	if (isset($capitali['francia']))
		echo "variabile definita <br>";
	else
		echo "variabile non definita <br>";

?>