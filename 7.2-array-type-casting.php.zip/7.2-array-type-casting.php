<!--

	Strutture di controllo e Array in PHP
	Casting e Overwriting delle chiavi

	Disponibile su devACADEMY.it

-->

<?php

	$vettore=array(
		false => "falso",
		"3" => "tre",
		2.5 => "due punto cinque",
		true => "vero",
		1.5 => "uno punto cinque"
	);

	$vettore[]="ultimo elemento";

	var_dump($vettore);

?>