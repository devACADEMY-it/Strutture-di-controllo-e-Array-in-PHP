<!--

	Strutture di controllo e Array in PHP
	Esempio ciclo while

	Disponibile su devACADEMY.it

-->

<?php

   $numero=2;

   do
   {
     $i=1;

     while($i<=10)
	   echo ($i++*$numero)."\t";

	 echo "<br>";
   }
   while(++$numero<=10);

?>