<!--

	Strutture di controllo e Array in PHP
	Funzioni per il popolamento di Array

	Disponibile su devACADEMY.it

-->

<?php

	$vettore=array(12,76,9,23,44,76,1);
	echo "Dimensione del'array: ".count($vettore);
	echo "<br><br>";

	$primo=array_fill(0, 10,'testo di prova');
	print_r($primo);
	echo "<br><br>";

	$secondo=array_fill(6, 10, -1);
	print_r($secondo);
	echo "<br><br>";

	$terzo=range(15,34);
	print_r($terzo);
	echo "<br><br>";

	$quarto=range(49,38);
	print_r($quarto);
	echo "<br><br>";

	print_r(range('d','n'));

?>