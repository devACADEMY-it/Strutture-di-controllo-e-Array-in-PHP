<!--

	Strutture di controllo e Array in PHP
	Esempio ciclo for

	Disponibile su devACADEMY.it

-->

<?php

  for ($numero=2; $numero<=10; $numero++)
  {
	for ($i=1; $i<=10; $i++)
	  echo ($i*$numero)."\t";
	echo "<br>";
  }

?>