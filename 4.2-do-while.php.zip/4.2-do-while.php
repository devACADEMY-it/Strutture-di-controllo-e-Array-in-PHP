<!--

	Strutture di controllo e Array in PHP
	Il ciclo do…while

	Disponibile su devACADEMY.it

-->

<?php

	$i=1;

	do
	{
		echo ($i*2)."<br>";
		$i++;
	}
	while($i<=1);

?>