<!--

	Strutture di controllo e Array in PHP
	Il costrutto if

	Disponibile su devACADEMY.it

-->

<?php

	$numero=20;

	if ($numero>=5 && $numero<=15)
	{
		echo "*** ";

		echo "$numero compreso tra 5 e 15";
		echo " ***";
	}

?>