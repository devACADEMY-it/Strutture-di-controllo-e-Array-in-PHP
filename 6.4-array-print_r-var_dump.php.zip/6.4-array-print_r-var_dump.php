<!--

	Strutture di controllo e Array in PHP
	Funzioni print_r e var_dump

	Disponibile su devACADEMY.it

-->

<?php

	$valori["parola"]="cavallo";
	$valori[0]="gatto";
	$valori[]=100;
	$valori["numero"]=150;

	print_r($valori);

	var_dump($valori);

?>