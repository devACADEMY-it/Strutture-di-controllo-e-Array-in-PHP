<!--

	Strutture di controllo e Array in PHP
	Interruzione dello script: exit e die

	Disponibile su devACADEMY.it

-->

<?php

		$divisore=0;

		if ($divisore==0)
			//exit;
			die("Divisione per zero vietata");
		echo 45/$divisore;

?>