<!--

	Strutture di controllo e Array in PHP
	Funzioni di push, pop, shift, merge…

	Disponibile su devACADEMY.it

-->

<?php

	$vettore=
	array( 12,56,78,3,123,55);
	var_dump($vettore);

	array_push($vettore, 111,222,333,444);
	var_dump($vettore);

	echo "<br>";

	echo array_pop($vettore);
	var_dump($vettore);

	echo "<br>";

	echo array_shift($vettore);
	var_dump($vettore);

	array_unshift($vettore, 88,77,66);
	var_dump($vettore);

?>