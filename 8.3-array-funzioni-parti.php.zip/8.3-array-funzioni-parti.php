<!--

	Strutture di controllo e Array in PHP
	Funzioni di splice, slice, chunk, unset…

	Disponibile su devACADEMY.it

-->

<?php

	$vettore=
	array( 12,56,78,3,123,55,61,22,37);

	var_dump($vettore);

	$primo=array_slice($vettore, 4);
	var_dump($primo);

	$secondo=array_slice($vettore, 4, 2);
	var_dump($secondo);

	$terzo=array_chunk($vettore, 3);
	var_dump($terzo);

	unset($vettore[2]);
	print_r($vettore);

?>