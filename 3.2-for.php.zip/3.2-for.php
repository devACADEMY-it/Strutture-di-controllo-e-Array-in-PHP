<!--

	Strutture di controllo e Array in PHP
	Il ciclo for

	Disponibile su devACADEMY.it

-->

<?php

	for ($i=0; $i<10; )
		echo "Ciao Mondo! <br>";

	echo "FINE SCRIPT";

?>