<!--

	Strutture di controllo e Array in PHP
	Array associativi

	Disponibile su devACADEMY.it

-->

<?php

	$vettore=array('uno' => 1,
					'due' => "secondo",
					'tre' => 3);

	echo $vettore['due'];
	echo "<br>";


	$secondo_vettore=['uno' => 1,
					'due' => "secondo",
					'tre' => 3];
	echo $secondo_vettore['uno'];
	echo "<br>";



	$pagella['storia']=10;
	echo "voto di storia ".$pagella['storia'];
	echo "<br>";

	$pagella['matematica']=9;
	echo "voto di matematica ".$pagella['matematica'];
	echo "<br>";

	$pagella[]=7;
	echo "ultimo elemento inserito ".$pagella[0];
	echo "<br>";

	$pagella['geografia']=8;
	echo "voto di geografia ".$pagella['geografia'];
	echo "<br>";

	$pagella[]=5;
	echo "ultimo elemento inserito ".$pagella[1];
	echo "<br>";

?>